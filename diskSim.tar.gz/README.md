# Disk Scheduling Simulator

The simulator supports FCFS, SSTF, SCAN, C-SCAN, LOOK, and C-LOOK on a disk with cylinders 0 through 4999.

Compile and run:

```sh
gcc -std=c11 -Wall -Wextra -pedantic main.c -o diskSim
./diskSim INITIAL_POSITION [ACCESS_SEQUENCE_FILE]
```

`INITIAL_POSITION` is required and must be between -4999 and 4999. Its magnitude is the starting cylinder; a negative value means the head initially moves toward cylinder 0, and a positive value means it moves toward cylinder 4999. If `ACCESS_SEQUENCE_FILE` is omitted, the program generates 100 random requests. If provided, the file should contain integer requests from 0 to 4999, one per line.

The program prints one line per algorithm, with the algorithm name and total head movement.
